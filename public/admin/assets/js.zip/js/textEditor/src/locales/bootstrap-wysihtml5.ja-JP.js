/**
 * Japanese translation for bootstrap-wysihtml5
 */
(function($){
    $.fn.wysihtml5.locale["ja-JP"] = {
        font_styles: {
            normal: "通常の文字",
            h1: "見出し1",
            h2: "見出し2",
            h3: "見出し3",
            h4: "見出し4",
            h5: "見出し5",
            h6: "見出し6"
        },
        emphasis: {
            bold: "太字",
            italic: "斜体",
            underline: "下線"
        },
        lists: {
            unordered: "点字リスト",
            ordered: "数字リスト",
            outdent: "左寄せ",
            indent: "右寄せ"
        },
        link: {
            insert: "リンクの挿入",
            cancel: "キャンセル",
            target: "新しいウィンドウでリンクを開く"
        },
        image: {
            insert: "画像の挿入",
            cancel: "キャンセル"
        },
        html: {
            edit: "HTMLを編集"
        },
        colours: {
            black: "黒色",
            silver: "シルバー",
            gray: "グレー",
            maroon: "栗色",
            red: "赤色",
            purple: "紫色",
            green: "緑色",
            olive: "オリーブ",
            navy: "ネイビー",
            blue: "青色",
            orange: "オレンジ"
        }

    };
}(jQuery));
